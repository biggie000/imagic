-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_afzjjyxlxjbyusdvibjsokarwlijouqixpew` (`ownerId`),
  CONSTRAINT `fk_afzjjyxlxjbyusdvibjsokarwlijouqixpew` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvstsusxfvoulexskzbuzmgqyljbthwcreyq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qlnuyxdhkwyqvxspzzotfmofypjwphbifkhk` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_ixrfjzsqdiusaqasqqblbiccadlfcvidnxnt` (`dateRead`),
  KEY `fk_lvbjxagwjksecfgpmwomskkvyhjkbkpbwriw` (`pluginId`),
  CONSTRAINT `fk_bzsrllynkrjrbazccgcyrcjvsbwxijsmphqq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lvbjxagwjksecfgpmwomskkvyhjkbkpbwriw` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ssmsmxekbgfcsqjsewaqxkpunkewgfjxfyec` (`sessionId`,`volumeId`),
  KEY `idx_bcbvykhxsfvrzgjvjkzyvccrrntgqghfguzy` (`volumeId`),
  CONSTRAINT `fk_rdtyigehixnpinzbbzzcbmatzshkfsfntdyo` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uakpjpghgenfdzmpniocuffvkahdetiteqon` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ainrdrnbtissfosqdawdtqqvazbbplledids` (`filename`,`folderId`),
  KEY `idx_qnaqagummlpabjqolfrlbutluonfwfivqflo` (`folderId`),
  KEY `idx_witzcuyyiiglnnzgakwypyiccoqkdwsaptlj` (`volumeId`),
  KEY `fk_praplrbnbwfflllimlwcgmbeoyjavtmgszad` (`uploaderId`),
  CONSTRAINT `fk_oynnqtynetiqfagejvjxcrmpydtmhdlbmzkk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_praplrbnbwfflllimlwcgmbeoyjavtmgszad` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vkjqwshqcrnkcwbsmqanmvtvovavrqyilzyy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zldxcvozsgrirtushaykmzyjbvzrrvueluyu` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xxalbboyzvaykafvsdcyhzknthnbyavcellc` (`groupId`),
  KEY `fk_iewrxbrleipfbukhnlchicazfuvjffiwgthh` (`parentId`),
  CONSTRAINT `fk_afaavryxgzhsankuvvtcsvpstjwlvwsodtlv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iewrxbrleipfbukhnlchicazfuvjffiwgthh` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tovqrinxxcfuhlsykthqcpdcmxiotgrsvsnn` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qjwdlachevqddrtczaymtepqhngacgjmamru` (`name`),
  KEY `idx_xifsnrmklsmxurzfenundnqyitxibwbcwewh` (`handle`),
  KEY `idx_rgcymxiurcbdtcahdjcjvekfjymjaikypefe` (`structureId`),
  KEY `idx_wvivkldkcmfolgkowxqdpjkhkdjwqpknwvqj` (`fieldLayoutId`),
  KEY `idx_jrqpzbuuhgdqvjmfpencuvthzqhxntyqdtyr` (`dateDeleted`),
  CONSTRAINT `fk_wqyjrbabctrkmbnkzuzxplgaouzbiirqjbgf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xibljfubwlfntnynmnicbthtifyncjseradc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vkazjwmamymuzfyhnsuyvlqamxfabmuhcdxv` (`groupId`,`siteId`),
  KEY `idx_ynxuuslaergwqhpawaothqpwjznmnyuouxgn` (`siteId`),
  CONSTRAINT `fk_akcnnwfurjhwicvdidxgafwsfcohylonsghx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zznxgiemfhszqzuhaaqzpmpzsafmvmsvudzy` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_kdlzttfqvdvcommqzxlgqxrwjyudcqhjkbdq` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ebsjpozaxyjdwpdeokkjattonewlwmazhmqg` (`siteId`),
  KEY `fk_jnjhbhqczxsbovdgbljeukkzkokssvxqkagy` (`userId`),
  CONSTRAINT `fk_ebsjpozaxyjdwpdeokkjattonewlwmazhmqg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jnjhbhqczxsbovdgbljeukkzkokssvxqkagy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_kmuiseqzqlowdgshdgiforgkzwirmptizjhy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_untvpyfwicdoexdhdczdbtxiaqonojvfxlxx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zogngnaydgnqkplswiuenvegffvxptmqrvgd` (`siteId`),
  KEY `fk_zvrguuvyduauqftliityazjlekczcgvrthdj` (`fieldId`),
  KEY `fk_ufktqobeafudekarbisqazsupxfhviqhosfs` (`userId`),
  CONSTRAINT `fk_ufktqobeafudekarbisqazsupxfhviqhosfs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_uqigznsvusmkutkebauljzrpuqnndjcyrulz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zogngnaydgnqkplswiuenvegffvxptmqrvgd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zvrguuvyduauqftliityazjlekczcgvrthdj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heroTitle_fixrbccy` text,
  `field_sliderTitle_bwxxppql` text,
  `field_sliderDescription_qgvuhscd` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lybrwlrtwbuwvrwxpokniexwthlqnskakqtt` (`elementId`,`siteId`),
  KEY `idx_bdnvidpxyrbapmfjphkkxemmtbqgislpztxp` (`siteId`),
  KEY `idx_jdfbjzqwixpadzgklhtvqwojpqztsultytml` (`title`),
  CONSTRAINT `fk_kjhjezinggmimiizethcjszjxunbwehviqpj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mvgqkponqzosntcvjccyblkuvgssvgvicfew` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_murpeffzaeqbhlpvrdezsncnzwikbcbbjseb` (`userId`),
  CONSTRAINT `fk_murpeffzaeqbhlpvrdezsncnzwikbcbbjseb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_thufqlfsyjfovxlhgvnveiettlrlnswkdfnz` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_pahmtctezlhiukgzjypgdbahcmgsaupdmlmg` (`creatorId`,`provisional`),
  KEY `idx_clhdoxblyazypsluzhnoovabdniilkyerkfi` (`saved`),
  KEY `fk_abugmfdondjbziuiiyulpzgmnegdyietwvwc` (`canonicalId`),
  CONSTRAINT `fk_abugmfdondjbziuiiyulpzgmnegdyietwvwc` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bgoqkaqkqltcxaommbuxwbladcacgrpbkshy` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_qspubpypwgkpqcwwvvycawyukfbpcuikfyzb` (`elementId`,`timestamp`,`userId`),
  KEY `fk_tuboxwsnchwmahrddhqntwbogolajmayyfja` (`userId`),
  KEY `fk_mhvxjzxsenhktyfefltsthbfmboomaxbbssm` (`siteId`),
  KEY `fk_bzoizzijewhfvziuddwkmfukfuvukishvjrs` (`draftId`),
  CONSTRAINT `fk_bzoizzijewhfvziuddwkmfukfuvukishvjrs` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cmkwktkmgahpiydzelzxtwyspyymdpizpuqk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mhvxjzxsenhktyfefltsthbfmboomaxbbssm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tuboxwsnchwmahrddhqntwbogolajmayyfja` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vmwurpnzwcqhjhtbstuvtejqphvpimncscct` (`dateDeleted`),
  KEY `idx_skenanwgxryzhodzfyhbwpwheewllwlgwspr` (`fieldLayoutId`),
  KEY `idx_fezslxzagvgupamawltxbcvfmyqswyutapev` (`type`),
  KEY `idx_bzgfswolpwciyzdqltmgdojyaoshuxnixwch` (`enabled`),
  KEY `idx_wcnmcmqsbtkvyvsezzpnlexhvrfkrfchbadv` (`canonicalId`),
  KEY `idx_uhpekwgymsvudmhreicmifyielvzywqfyira` (`archived`,`dateCreated`),
  KEY `idx_bkutgdtjrzfmuiruykhtwguabztmsrryaqty` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_qkfwdjmwylynnnncsalnjilozvpvhdhrurfl` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_wygwdeurkgnylaovpiodfbupyifjqjvxarvh` (`draftId`),
  KEY `fk_cxublbhohlucdprontlbszjbxptsfjmpbxua` (`revisionId`),
  CONSTRAINT `fk_cxublbhohlucdprontlbszjbxptsfjmpbxua` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mlmxfgvmndxaskzdyiptllnbfajzqdmsexnb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wygwdeurkgnylaovpiodfbupyifjqjvxarvh` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xklfnvymskajtwkclujvreavsqcxiweoonoa` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qugeqbiicxbsvumvladiokokbpskscxgrmbe` (`elementId`,`siteId`),
  KEY `idx_abwgzdrljozqhiizgpyupiwjgxvnzacxshjk` (`siteId`),
  KEY `idx_ysatuwuhxiyfzhmlypzdxioqzxupmfucurut` (`slug`,`siteId`),
  KEY `idx_mdjhxqkdoivclncovronovklvbrhqpxcllhg` (`enabled`),
  KEY `idx_tbaxoplcotyekfygsryqvlryetrhcglrxszp` (`uri`,`siteId`),
  CONSTRAINT `fk_bnknskeyfrdhmontopqeuktwazphxxlhdzrp` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iueklzmqcxrcermmlyrdorvnbvbbpzsazdlz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_flakocqnvhqpnwryalvkkbwgwiewdqkrwpoj` (`postDate`),
  KEY `idx_sbgtutpwfnnadvesdbzfnfgssrpsbmbzbgri` (`expiryDate`),
  KEY `idx_vcvkqlmjvmfmzcrrsknupnjdcijxfxtdvkzp` (`authorId`),
  KEY `idx_mdruzorxalbeextjxmwptougcdhuwoxykknm` (`sectionId`),
  KEY `idx_onfmibveaoyrhwhemvosvelrubwhplgdhuya` (`typeId`),
  KEY `fk_kcemusklnxmyapmwdyybtzeobpgpvphdwfnq` (`parentId`),
  CONSTRAINT `fk_arxamdskwaupudlloosdifkabuolqnhgkart` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_eubadquxxunrvlceinrrshacvsclbzrqxrpy` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jkszticpadhudhecpmdbhwfqccmgxelycbep` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kcemusklnxmyapmwdyybtzeobpgpvphdwfnq` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ujfzsgcysrtgvxuaqqpapcwwlbenaytqwvpm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iylzpfkrbkfajenwuvprpvjxfgbhpnefixui` (`name`,`sectionId`),
  KEY `idx_tjmysotiglgtrsnpxizmxxsfpclodxwuxogf` (`handle`,`sectionId`),
  KEY `idx_pbpofvszzudtypesryaddedslncbitbdezwr` (`sectionId`),
  KEY `idx_hmmkagqeokuqctqdhjxgyhdeitydavghgilo` (`fieldLayoutId`),
  KEY `idx_qygusjkeqalzpvsqcbaugrieheosrhwbbbfm` (`dateDeleted`),
  CONSTRAINT `fk_pbfisrhipmcheoiprpcoktwmvjquphicqyhe` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ztlcawnvfcpbskdyonsqldbszpzetrwyqzpu` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lbxluembhlwrdvrjllilxjwrzuwaqlrcffgz` (`name`),
  KEY `idx_ctagoksnbayyhyfaukgizvzuczlqazkztllt` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zikxbwbhzldltsbgeyhdbmifolkhifgsprtv` (`layoutId`,`fieldId`),
  KEY `idx_edvhiezovyugzpvrpwjnhuldezzjzawsifgn` (`sortOrder`),
  KEY `idx_clbflzcxpncfpupqkvlxdkzdswtxwvuhvutk` (`tabId`),
  KEY `idx_udulpbrjyugrxkjktydrufbuxrduwkwpahxi` (`fieldId`),
  CONSTRAINT `fk_mxlhifjnujgvovyhnskkymmnrcssinkkuzgn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pjjrzggdyxvnywheadywjgciacabrsebkwjh` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yljvtqsppvsfiklijqkvgvazrwdbadbbyshn` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bjzlscmrtjsfohnzcvryhfluzmojosktnwzh` (`dateDeleted`),
  KEY `idx_iickufrqxrzhqjmfhdfhsgohwpgcixcrgckb` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mykehahkvdkxwapmxvyajxurpvscpktoyfwj` (`sortOrder`),
  KEY `idx_fxukqnlfigbqfrtmdxrkgjhqidaszkldwlba` (`layoutId`),
  CONSTRAINT `fk_cllcccpgukfuojjjmqqixzmtmrowdbqxwutw` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dksbojabjxvwaworhuisbinfivehlkzmmgaa` (`handle`,`context`),
  KEY `idx_diyahrsabrjczsnnfznojglzznqvvtsozvie` (`groupId`),
  KEY `idx_oybgthkpewvpfwyfqcvvkbudraclrtqtbbux` (`context`),
  CONSTRAINT `fk_fexzjpmbvaphgepuydlqdpxypcyokfgvcpaz` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bqlfqnmudxmxxmdzgtquyzopaqudyabkwwrv` (`name`),
  KEY `idx_yuzqzeyxzhrsoialatwmgzxhslorzifjjefp` (`handle`),
  KEY `idx_qrriyqzgxmpspeibgkhvsjdqaqfvbkpwjrqo` (`fieldLayoutId`),
  KEY `idx_anianhjmowdjeeyvglrtpwkdmcorvoeyroqk` (`sortOrder`),
  CONSTRAINT `fk_dsxwxhjseyrqdggqawsixcchvcedmwsxaupq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qoqnhkjlomxkiassbncngukqihbhlzehtcyj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ueunnzfyzmblpbyrzavkdhtucnyyntomkcas` (`accessToken`),
  UNIQUE KEY `idx_riucdajivihokdkuxnbdhjwbvpbkarovrnzi` (`name`),
  KEY `fk_afcxxyjpuurkogfmlxgvgmznvyvhtynfwnaz` (`schemaId`),
  CONSTRAINT `fk_afcxxyjpuurkogfmlxgvgmznvyvhtynfwnaz` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_osqdpugduaihqolnrfdmwvxchcljvnmeujjk` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hyimdqnwcxncvxtesxsnlnjpkhvvmiegclee` (`name`),
  KEY `idx_emcpubwulykfpfqmjzhpmzdkrmtwdlqfsuvc` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_olytpgxwaufgyfyyfgvygufufoxxziafycxb` (`primaryOwnerId`),
  KEY `idx_erxnhxhpsvqyqmdqfmtsvwyybsfcuvvcgfil` (`fieldId`),
  KEY `idx_wucmfxyyqvsdmnnyjbabsrglroszsmypfiya` (`typeId`),
  CONSTRAINT `fk_ajrlyytpreoyxsqcffhmchekbaljooxaelqe` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eatxskhylxctvcfxnhkbalefwxlwlwujjial` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reyobyxbxncorqoromokpybyomwrnaxmdzcr` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vkdrjwklmhnmmkzsvzmiufqpukattpdmmshn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_raxzbvlvgizjgqesnjxxunguayqszbpmzafc` (`ownerId`),
  CONSTRAINT `fk_fzsnfnniecpciitmizeuzujdaxjlouyndwrv` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_raxzbvlvgizjgqesnjxxunguayqszbpmzafc` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nlzawwuarhcppncvahihbtrqjpxllytdewsi` (`name`,`fieldId`),
  KEY `idx_ncptmvdbkaudmcaldxswyqznpxrjaudhuvji` (`handle`,`fieldId`),
  KEY `idx_oazhtvzzktwipwbpoqgixoanudzovpmxiqqd` (`fieldId`),
  KEY `idx_bhizhtrhyrchtecfzhhkenachrlvmjeiceka` (`fieldLayoutId`),
  CONSTRAINT `fk_entaeewljoswalhmtfmsogbukvsoolhswtbw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zhehfbtugqqoyeuoleogggskrmpkglvcejas` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_sliderimages`
--

DROP TABLE IF EXISTS `matrixcontent_sliderimages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixcontent_sliderimages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eqswxjgdcbuflxgsiulkhfiksjwhcrqgomun` (`elementId`,`siteId`),
  KEY `fk_uybnhsbupymbivujunkxythpcmzgljcezpca` (`siteId`),
  CONSTRAINT `fk_szyhcaxgbzoenkfvvptesvalzmssqtzcvhlj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uybnhsbupymbivujunkxythpcmzgljcezpca` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kogzlkmajdoqpmwomfagetvlclhbuqokmepi` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tdrjrqpizjzamehnkqzhrjvddifvcbodlapi` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_asgwiuodxsiqxtafwsgnanhnhejswjjkvqqy` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_hyuunttwsyglfqtpclbkzdbiuuszndtrkwnb` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hdllohactkbflyiduoijdbtzxtmbqgyigftm` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_lnxozhzgkvjgzdgnuukasulsueligmnowhwo` (`sourceId`),
  KEY `idx_tgiojttrnejkejwkkpcqvdwhkahxpzjqrqfj` (`targetId`),
  KEY `idx_ajqgmelqeyyhcxffchcvsvnogfglygpgsvdl` (`sourceSiteId`),
  CONSTRAINT `fk_gauaxjguwxtwdxczsoonzegusygecwhygvts` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kilvnabdweigyslrxyqudfytibfdrrrrxovm` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ngqskozntmptxqxhktuxtcpytntqgidyyrze` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gbadidzhsimsruxwyuxpupsxpofryvedvywi` (`canonicalId`,`num`),
  KEY `fk_rbtwmqmsfbuajbyrtmtaygnrpendynvpfrxl` (`creatorId`),
  CONSTRAINT `fk_rbtwmqmsfbuajbyrtmtaygnrpendynvpfrxl` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vewtaejeyhficjqwvyqlcnsievdhrsmgymaf` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_lemtygfwkaefwgiduteuvntjonbzahannxaj` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zbtsxbjanmwtgfxdomzfytdgrgplblwyabfk` (`handle`),
  KEY `idx_nykrnhodyaaqqnmotyviyspjtcppwkcitdwm` (`name`),
  KEY `idx_ljvxpplzvijfdedyvilctsjdbadbcyiegptj` (`structureId`),
  KEY `idx_ptjrvbbaxpkkfoelqaotyrqudrahymjscjbk` (`dateDeleted`),
  CONSTRAINT `fk_byqagbpsgqxwyqkfiifuweedfabuadvjdyoe` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mxlorkjfpratfyhfwvvphqnoftxkibpucdtq` (`sectionId`,`siteId`),
  KEY `idx_fwylusqdbgwiehqigwrwcautvosthcjrkyxh` (`siteId`),
  CONSTRAINT `fk_axoplzhtntcehdnwoxxsgtfejtvphjadtocw` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yoqrmbptjvwyyjpskucsjrbesuruwosgblpx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ekfkeoevcxfitghxdjicofdzamtwcfhtjbcf` (`uid`),
  KEY `idx_tppscovsxfjdobhjmjxycxdtpunjuedkwvwp` (`token`),
  KEY `idx_zxhvdtxtycwttusyqusodqofsfiyafpfofww` (`dateUpdated`),
  KEY `idx_wynchjouezasinbihfnvvgoavmqhsvefbogb` (`userId`),
  CONSTRAINT `fk_yrbtkqzabydquqbtuwnfjmsitsrkwwrfbuxx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lbawiwhnwcoageptsuthhymrbxgptwbknzym` (`userId`,`message`),
  CONSTRAINT `fk_bswtoyktpwqictnnxtjmbfpqcfocwtteqqbm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sogdleqdufafavyycfbphcfadhaocwltsjys` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ewnfvhyebkhnsnpzgdfnelerolydrgcacath` (`dateDeleted`),
  KEY `idx_ayxhsognhyuwccyejzcjlizpugoxwcwalfhq` (`handle`),
  KEY `idx_ovcadigfehgxtkgpobjwixrzdkkmktbjcxko` (`sortOrder`),
  KEY `fk_sriyhamzbkylpgfcnekzsgltiyqhvtpjolkq` (`groupId`),
  CONSTRAINT `fk_sriyhamzbkylpgfcnekzsgltiyqhvtpjolkq` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oubpkzpzakbxjiovgrdpwmpjbucndeipvsbg` (`structureId`,`elementId`),
  KEY `idx_jltsbkpgzgujnjqldyzvkeqwzzmgflmiqtra` (`root`),
  KEY `idx_nhztvlnhjkyvgtmclahypydzbzkxrawgrftb` (`lft`),
  KEY `idx_rypbnssiitbckbooomqbxdvlytqikkvfxvqv` (`rgt`),
  KEY `idx_lamtcrnxhvfkspgpzkqdvmxgkeyzchpfldlc` (`level`),
  KEY `idx_irrkzllvywdycmcixmoltiqqoojzudxzqvve` (`elementId`),
  CONSTRAINT `fk_zkplwentyusgptmbczoptjcwfdkkpbfjexgy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ewxnwncgjvbaunazcogoqjgqxsoqvbthmhfe` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kkkknzuoorrdxbxkglpfyjxfummamfptixmx` (`key`,`language`),
  KEY `idx_arzakwttxrwoxavzdyeannrfwpotacjiuzut` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mqlkwlbvooqioyxamjcoadwyauilrfxiuxkc` (`name`),
  KEY `idx_wzfmtbuxrujazzyhfpxuqxevkgsvvkhezvnm` (`handle`),
  KEY `idx_bcvxgbldvtfpahleuyfovbkcemzlixwomvrl` (`dateDeleted`),
  KEY `fk_cviymgplmmaoltefcpeyafqgnyibudzannkg` (`fieldLayoutId`),
  CONSTRAINT `fk_cviymgplmmaoltefcpeyafqgnyibudzannkg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jdhzqkotlwhsbdublwosjxvimzhcihvjlvjb` (`groupId`),
  CONSTRAINT `fk_cmuurnyhpqvegclcjcfjeajxclpxfztvviez` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fvuqflpuxmsgxvtwgrtzadzeawqilmmcbddg` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_arbkbffyoddrytfwnzcufrlvcodldteelabl` (`token`),
  KEY `idx_kckvnahjihrttoyhqxfdpdieflombtuhenov` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hsunwsfcnygzytbnqpqlqawjopwfcxsggkev` (`handle`),
  KEY `idx_qbfchxkumbqelghrswgmmkdfemtnjqouevld` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ixmlqdfwhcnbcwunjnhxavsyepnjabloqavb` (`groupId`,`userId`),
  KEY `idx_pztmlglxhirjzgdibdddovxuivvaidwxkvkw` (`userId`),
  CONSTRAINT `fk_bagytnnlkndagbeftahuyoqohglfibjfybgq` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpfoeaymhcwxfiejiyxcscvgnyvhvnotozbz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kvvwjtqeaesujszviebsedfmxzwneaeucrhg` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gktognxhqwxkfmebkokjtltlftczmviagrks` (`permissionId`,`groupId`),
  KEY `idx_uyzuoyjlcehulgadbxmigfwzkaexvyeibfmm` (`groupId`),
  CONSTRAINT `fk_dxgawgeggykbbfqbnfntwucjjxkvieokvnns` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qyyxogkanhwhhszmzzekkxhqhjfbhgmfgxft` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vzwtiulvmnucvhfucjioaeoheaevfopnvarc` (`permissionId`,`userId`),
  KEY `idx_odklhobyeoyhielffqtwolthxpfpbwwuinjz` (`userId`),
  CONSTRAINT `fk_eeihiflpwhmusxgzpahyjzlqsxbzrhovujrk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xparqjanqzrfcvawtodmpivvugaqyxyqnidg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_sceqhvbohqyngnzwnclfqlksaxqqcpwrmuxs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gsuexdcostsjnebpuegcbhzajlzshyypxups` (`active`),
  KEY `idx_luwkzqscippmlctwsjrijspknfixotsntvhc` (`locked`),
  KEY `idx_hvqsabdvelymjnfykultxjrmsahotwhqkgex` (`pending`),
  KEY `idx_srftrbjoiuovrqnrwhcqpwauwlkbdlcvimbr` (`suspended`),
  KEY `idx_xsuygdyvxxfjkbmhcctmistyajhvnteqlrem` (`verificationCode`),
  KEY `idx_ccynzqmhjroseeiorelkeoggtbwctbuqcwcc` (`email`),
  KEY `idx_lzirjainqryaewtlalnlxcsgebiruginjntg` (`username`),
  KEY `fk_yvwpccjleuxymzlbqcsdnughiomtvhxibqpx` (`photoId`),
  CONSTRAINT `fk_rhnkshwveynjlelnlnmaftmovqjizulnkftx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvwpccjleuxymzlbqcsdnughiomtvhxibqpx` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jfrrdaaiykcawgdcstmlriirpmejchgriqwe` (`name`,`parentId`,`volumeId`),
  KEY `idx_udfziijtpnkuiotmlmpvkabekaxdutwqsjgk` (`parentId`),
  KEY `idx_ljsbfwxdjjjukbkzgmdyimgjibqmtulatatb` (`volumeId`),
  CONSTRAINT `fk_rrobfhaknimabmhggdedoqaedzynnualfxch` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sjgaanzchhhmcwizqhrcczpjrgjowvvweiav` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xzxhiidoauhfzvifrnjzrjrgxfgdkcmrlbwp` (`name`),
  KEY `idx_iuxgfxxayaiwvfngzgrlwccdrinreekhkzqv` (`handle`),
  KEY `idx_agjadqrihieoarzmpywmydvdyreewvltqzpd` (`fieldLayoutId`),
  KEY `idx_grvtkvuwrurxdfwdasqbhmyyseoaemrajuta` (`dateDeleted`),
  CONSTRAINT `fk_cbezelamzjmdrylcgjhmmvmqmimlntxdwark` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qicxlsvgxnvesschtqrcuzsfvbhqlgdunswz` (`userId`),
  CONSTRAINT `fk_xahvjzjoccwwflrubzqsxxxszcogpdqfibnb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-16  9:25:50
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (8,1,1,1,'hero.jpg','image',NULL,1500,1001,177661,NULL,0,0,'2024-12-18 00:01:38','2024-12-18 00:01:39','2024-12-18 00:01:39'),(13,1,1,1,'hero_2024-12-18-001035_paba.jpg','image',NULL,1500,1001,177661,NULL,0,0,'2024-12-18 00:10:35','2024-12-18 00:10:36','2024-12-18 00:10:36'),(16,1,1,1,'hero_2024-12-18-001229_maxf.jpg','image',NULL,1500,1001,177661,NULL,0,0,'2024-12-18 00:12:30','2024-12-18 00:12:30','2024-12-18 00:12:30'),(18,1,1,1,'hero_2024-12-18-001307_jwwm.jpg','image',NULL,1500,1001,177661,NULL,0,0,'2024-12-18 00:13:08','2024-12-18 00:13:08','2024-12-18 00:13:08'),(22,1,1,1,'hero_2024-12-18-002426_hyqb.jpg','image',NULL,1500,1001,177661,NULL,0,0,'2024-12-18 00:24:27','2024-12-18 00:24:27','2024-12-18 00:24:27'),(28,1,1,1,'CBHB.jpg','image',NULL,1784,1214,175279,NULL,0,0,'2024-12-18 17:51:33','2024-12-18 17:51:36','2024-12-18 17:51:36'),(29,1,1,1,'Faringdon.jpg','image',NULL,1784,1214,190921,NULL,0,0,'2024-12-18 17:51:39','2024-12-18 17:51:41','2024-12-18 17:51:41'),(33,1,1,1,'Platinum.jpg','image',NULL,1784,1214,344299,NULL,0,0,'2024-12-18 17:51:51','2024-12-18 17:51:52','2024-12-18 17:51:52'),(38,1,1,1,'Signtech.jpg','image',NULL,1784,1214,623432,NULL,0,0,'2024-12-18 17:52:12','2024-12-18 17:52:14','2024-12-18 17:52:14'),(65,1,1,1,'hero.jpg','image',NULL,1500,1001,177661,NULL,NULL,NULL,'2025-01-15 10:31:22','2025-01-15 10:31:24','2025-01-15 10:31:24'),(66,1,1,1,'CBHB.jpg','image',NULL,1784,1214,175279,NULL,NULL,NULL,'2025-01-15 10:31:47','2025-01-15 10:31:47','2025-01-15 10:31:47'),(67,1,1,1,'Faringdon.jpg','image',NULL,1784,1214,190921,NULL,NULL,NULL,'2025-01-15 10:31:50','2025-01-15 10:31:51','2025-01-15 10:31:51'),(68,1,1,1,'Platinum.jpg','image',NULL,1784,1214,344299,NULL,NULL,NULL,'2025-01-15 10:31:55','2025-01-15 10:31:56','2025-01-15 10:31:56'),(69,1,1,1,'Signtech.jpg','image',NULL,1784,1214,623432,NULL,NULL,NULL,'2025-01-15 10:32:00','2025-01-15 10:32:01','2025-01-15 10:32:01');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (2,1,1,'2024-12-18 00:00:42',0,1),(2,1,2,'2025-01-15 10:33:08',0,1),(2,1,3,'2024-12-18 17:53:02',0,1),(2,1,4,'2024-12-18 17:53:02',0,1),(2,1,5,'2025-01-15 10:36:44',0,1),(51,1,6,'2025-01-15 10:36:42',0,1),(52,1,6,'2025-01-15 10:36:42',0,1),(53,1,6,'2025-01-15 10:36:42',0,1),(54,1,6,'2025-01-15 10:36:42',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2024-12-17 21:59:01','2024-12-17 21:59:01','fa6a8119-6daa-4934-98a4-514a716a6a6d',NULL,NULL,NULL),(2,2,1,'Home','2024-12-17 22:43:22','2025-01-15 10:36:41','123aa3fb-1b79-4ca4-98b6-003ac1572e00','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(3,3,1,'Home','2024-12-17 22:43:22','2024-12-17 22:43:22','b46388cb-a6db-450a-b0ea-59efbac59e78',NULL,NULL,NULL),(4,4,1,'Home','2024-12-17 22:43:23','2024-12-17 22:43:23','bfdfe7f3-5d64-4861-a228-7981aaacd495',NULL,NULL,NULL),(5,5,1,'Home','2024-12-17 23:59:30','2024-12-17 23:59:30','6c0a87ac-8367-4b8b-925c-05d58d58d108',NULL,NULL,NULL),(7,7,1,'Home','2024-12-18 00:00:42','2024-12-18 00:00:42','df7d5e82-3527-4db7-9f2a-56834902cf8c','Adapt, connect and grow',NULL,NULL),(8,8,1,'Hero','2024-12-18 00:01:37','2024-12-18 00:01:37','a432e577-7a32-43ce-a7b8-1aa28df55b48',NULL,NULL,NULL),(10,10,1,'Home','2024-12-18 00:01:58','2024-12-18 00:01:58','e5a76937-13b6-466c-879c-a1b2226dad02','Adapt, connect and grow',NULL,NULL),(13,13,1,'Hero','2024-12-18 00:10:35','2024-12-18 00:10:35','cd297ce2-339b-4029-9168-9ab9d86a2e11',NULL,NULL,NULL),(14,14,1,'Home','2024-12-18 00:11:22','2024-12-18 00:11:22','c3b983fa-5767-4121-ad17-cf1eb56674b6','Adapt, connect and grow',NULL,NULL),(16,16,1,'Hero','2024-12-18 00:12:29','2024-12-18 00:12:29','6cb6fe5b-64ee-4044-adfa-ed4370c3c985',NULL,NULL,NULL),(17,17,1,'Home','2024-12-18 00:12:42','2024-12-18 00:12:42','8c5dfe7c-e852-4592-9a96-212147aaa9f6','Adapt, connect and grow',NULL,NULL),(18,18,1,'Hero','2024-12-18 00:13:07','2024-12-18 00:13:07','15628d77-10e3-4e81-9785-7516feecb23f',NULL,NULL,NULL),(20,20,1,'Home','2024-12-18 00:13:16','2024-12-18 00:13:16','59c41041-77f9-49ae-9787-dabd3f62b152','Adapt, connect and grow',NULL,NULL),(22,22,1,'Hero','2024-12-18 00:24:27','2024-12-18 00:24:27','d155e78e-c762-4f03-ad73-cb646fce6e3d',NULL,NULL,NULL),(23,23,1,'Home','2024-12-18 00:24:42','2024-12-18 00:24:42','edd5e7e0-ffbb-4a27-b817-3506ad92e138','Adapt, connect and grow',NULL,NULL),(24,24,1,'Home','2024-12-18 17:49:51','2024-12-18 17:49:51','c3446be5-5105-43f0-93d8-7c61307b82ec','Adapt, connect and grow',NULL,NULL),(26,28,1,'CBHB','2024-12-18 17:51:31','2024-12-18 17:51:31','00fbd0fc-f0a8-41b5-b30e-451f12dc4ed2',NULL,NULL,NULL),(27,29,1,'Faringdon','2024-12-18 17:51:39','2024-12-18 17:51:39','ff147210-062a-4c5e-8a0a-976d03c6ba1e',NULL,NULL,NULL),(28,33,1,'Platinum','2024-12-18 17:51:51','2024-12-18 17:51:51','ee170751-a017-4e13-8a54-fd2f43266be8',NULL,NULL,NULL),(29,38,1,'Signtech','2024-12-18 17:52:12','2024-12-18 17:52:12','cc56784b-6986-4702-b8e0-cb81bf676dbc',NULL,NULL,NULL),(30,55,1,'Home','2024-12-18 17:53:04','2024-12-18 17:53:04','c06641e2-f8e9-4eb1-bf75-6618236f2274','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(31,60,1,'Home','2024-12-18 17:55:16','2024-12-18 17:55:16','a7eb7ee1-26aa-4dbe-857d-be1ea83919c1','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(33,62,1,'Home','2025-01-15 10:24:17','2025-01-15 10:24:17','112f504e-aaae-4b8b-bf4a-b7ce22fe45a4','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(35,64,1,'Home','2025-01-15 10:28:40','2025-01-15 10:28:40','33e0df86-2ebb-46cb-965b-ab37612d2577','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(36,65,1,'Hero','2025-01-15 10:31:22','2025-01-15 10:31:22','648bece3-34d5-4bda-945f-e68c4d8d65a9',NULL,NULL,NULL),(37,66,1,'CBHB','2025-01-15 10:31:46','2025-01-15 10:31:46','a17aa23e-2d28-4e44-995a-50e5279b02ed',NULL,NULL,NULL),(38,67,1,'Faringdon','2025-01-15 10:31:50','2025-01-15 10:31:50','b49f3f85-1dd9-4e4f-a039-6d7cee61c109',NULL,NULL,NULL),(39,68,1,'Platinum','2025-01-15 10:31:55','2025-01-15 10:31:55','f63d44a2-b974-429d-a6c9-77c3888a4b03',NULL,NULL,NULL),(40,69,1,'Signtech','2025-01-15 10:31:59','2025-01-15 10:31:59','f8498772-763e-4e7d-b5c9-c38eab82392a',NULL,NULL,NULL),(42,71,1,'Home','2025-01-15 10:33:07','2025-01-15 10:33:07','2285fb01-4f28-4477-98b7-30075429efce','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.'),(44,77,1,'Home','2025-01-15 10:36:42','2025-01-15 10:36:42','d5620ea4-5640-4719-8c69-bec8b9d86a15','Adapt, connect and grow','Our Work','Here you will find examples of campaigns and assets that have helped our clients adapt their brand, connect with new customers, and grow market share.');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2025-01-15 10:36:37'),(2,1,1,NULL,'save','2025-01-15 10:36:44');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-12-17 21:59:01','2024-12-17 21:59:01',NULL,NULL,'6054e9ed-2b2e-4129-9fa4-850055f25508'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-12-17 22:43:22','2025-01-15 10:36:41',NULL,NULL,'877be153-e8b4-4624-a20a-fed9ca24cf71'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-12-17 22:43:22','2024-12-17 22:43:22',NULL,NULL,'8008a291-196c-490a-b432-af3b6582c1d0'),(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-12-17 22:43:23','2024-12-17 22:43:23',NULL,NULL,'89e6d89a-c0a0-4b4f-a598-c1dbf5513bbb'),(5,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-12-17 23:59:29','2024-12-17 23:59:30',NULL,NULL,'4657db40-b170-43f1-b903-f6c1a692551c'),(7,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:00:42','2024-12-18 00:00:42',NULL,NULL,'51d7846f-49a7-464d-bba4-6704dca16638'),(8,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 00:01:36','2024-12-18 00:01:36',NULL,'2025-01-15 10:31:09','bc3f651b-a05a-4e51-9099-7c1af7a2bcb8'),(10,2,NULL,5,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:01:57','2024-12-18 00:01:58',NULL,NULL,'78f5a511-1390-4f01-9610-ff85221ea6f8'),(13,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 00:10:35','2024-12-18 00:10:35',NULL,'2025-01-15 10:31:09','7ce56154-b391-47e0-b8db-f28333b9c42f'),(14,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:11:22','2024-12-18 00:11:22',NULL,NULL,'1e3e8ec0-1ced-4387-acd6-605322728863'),(16,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 00:12:29','2024-12-18 00:12:29',NULL,'2025-01-15 10:31:09','cec501cb-2615-4351-b368-4a1773c31633'),(17,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:12:41','2024-12-18 00:12:42',NULL,NULL,'b6cd62b5-7ee0-47fb-a8d5-be46183b9070'),(18,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 00:13:07','2024-12-18 00:13:07',NULL,'2025-01-15 10:31:09','bb5daf80-0c30-4a98-aa5c-7fbf6603673f'),(20,2,NULL,8,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:13:16','2024-12-18 00:13:16',NULL,NULL,'32d5f88f-14c5-4a5a-856e-fe36dc18d738'),(22,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 00:24:26','2024-12-18 00:24:26',NULL,'2025-01-15 10:31:10','af35c721-a7f3-495b-b67c-58578a061870'),(23,2,NULL,9,1,'craft\\elements\\Entry',1,0,'2024-12-18 00:24:42','2024-12-18 00:24:42',NULL,NULL,'d70b0561-d8e0-40f8-bc7f-9bf8ccdab61c'),(24,2,NULL,10,1,'craft\\elements\\Entry',1,0,'2024-12-18 17:49:51','2024-12-18 17:49:51',NULL,NULL,'20d6d245-ad45-4bf3-a4ab-7cd5cbe63de0'),(26,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:08','2024-12-18 17:51:08',NULL,'2024-12-18 17:51:46','bee3d68f-1957-42be-bd0b-36d41774ff9f'),(27,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:09','2024-12-18 17:51:09',NULL,'2024-12-18 17:51:47','c1c50e9e-5823-48da-8c60-d017037f4978'),(28,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 17:51:31','2024-12-18 17:51:31',NULL,'2025-01-15 10:31:10','ccdb8654-6531-4665-8683-cc4cc3c5c693'),(29,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 17:51:38','2024-12-18 17:51:38',NULL,'2025-01-15 10:31:10','7318c0b4-00eb-47ea-ac85-d2ac904d728e'),(30,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:46','2024-12-18 17:51:46',NULL,'2024-12-18 17:51:59','c104b9c3-cc33-49f2-a987-20fd5a99ade6'),(31,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:46','2024-12-18 17:51:46',NULL,'2024-12-18 17:51:59','7de579c7-9c84-4ee7-bb23-ca622eb93d22'),(32,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:46','2024-12-18 17:51:46',NULL,'2024-12-18 17:51:59','8a4f2163-336a-47e8-b1df-0964c8e8c38d'),(33,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 17:51:51','2024-12-18 17:51:51',NULL,'2025-01-15 10:31:10','01589eb3-aed9-45d2-b514-8d90cb24cb1c'),(34,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:57','2024-12-18 17:51:57',NULL,'2024-12-18 17:52:23','cdafe238-9c7c-463f-b101-8026dfb7c67a'),(35,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:58','2024-12-18 17:51:58',NULL,'2024-12-18 17:52:23','b501032d-d96f-4663-9e6d-5aa5ac02667e'),(36,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:58','2024-12-18 17:51:58',NULL,'2024-12-18 17:52:23','8f6f401f-9c4d-41e9-9751-2fa48057251d'),(37,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:51:59','2024-12-18 17:51:59',NULL,'2024-12-18 17:52:23','d585324d-f810-4f1c-947f-9758277a5453'),(38,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-12-18 17:52:12','2024-12-18 17:52:12',NULL,'2025-01-15 10:31:10','603b1763-99f2-4774-8d8f-b58ed897039a'),(39,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:22','2024-12-18 17:52:22',NULL,'2024-12-18 17:52:41','561f7f22-3952-4532-b4f2-3d16fe742334'),(40,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:22','2024-12-18 17:52:22',NULL,'2024-12-18 17:52:41','b14a5890-9a94-4030-842c-b3cbf148a24f'),(41,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:22','2024-12-18 17:52:22',NULL,'2024-12-18 17:52:41','7cf63817-be10-475d-99c0-d88b1462cc83'),(42,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:22','2024-12-18 17:52:22',NULL,'2024-12-18 17:52:41','63305e50-6433-408e-9b4b-63898a581e2a'),(43,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:40','2024-12-18 17:52:40',NULL,'2024-12-18 17:53:02','797de19d-a956-4b15-b086-3d8c7cc8876b'),(44,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:40','2024-12-18 17:52:40',NULL,'2024-12-18 17:53:02','8e95d4ac-a7bf-4897-9b3d-5790e80c8890'),(45,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:41','2024-12-18 17:52:41',NULL,'2024-12-18 17:53:02','6c1fb8cf-af27-45c9-a097-6153a4c6de45'),(46,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:52:41','2024-12-18 17:52:41',NULL,'2024-12-18 17:53:02','3357aec4-d8d2-4c52-b50c-bcbb32be4ebc'),(51,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2025-01-15 10:36:42',NULL,NULL,'f56c71a0-db5c-4937-9ff7-5394682693c2'),(52,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2025-01-15 10:36:42',NULL,NULL,'9c998247-ee52-4819-a78b-34bfa9181520'),(53,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2025-01-15 10:36:42',NULL,NULL,'536dbd6e-f3cd-48e3-ad67-638c50038568'),(54,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2025-01-15 10:36:42',NULL,NULL,'734b0d50-60a4-448e-b5dc-dc71409ac2ea'),(55,2,NULL,11,1,'craft\\elements\\Entry',1,0,'2024-12-18 17:53:02','2024-12-18 17:53:04',NULL,NULL,'f004fc49-3d79-4d90-be1d-8b23751a8285'),(56,51,NULL,12,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2024-12-18 17:53:04',NULL,NULL,'6b90d246-a8d8-43df-9719-484ac59a61b2'),(57,52,NULL,13,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2024-12-18 17:53:04',NULL,NULL,'1b533759-54b4-45ec-9c8e-1055937f2eb6'),(58,53,NULL,14,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2024-12-18 17:53:05',NULL,NULL,'8f47c8f7-0096-48fe-993c-2ec006a22042'),(59,54,NULL,15,3,'craft\\elements\\MatrixBlock',1,0,'2024-12-18 17:53:03','2024-12-18 17:53:05',NULL,NULL,'ed9bde89-e33c-4faf-b03e-638565f2f1e4'),(60,2,NULL,16,1,'craft\\elements\\Entry',1,0,'2024-12-18 17:55:16','2024-12-18 17:55:16',NULL,NULL,'d923676e-ca1e-41c8-87cb-55d53fd3e9dc'),(62,2,NULL,17,1,'craft\\elements\\Entry',1,0,'2025-01-15 10:24:17','2025-01-15 10:24:17',NULL,NULL,'2d0795e9-95b4-47f5-a123-9a9789d54efb'),(64,2,NULL,18,1,'craft\\elements\\Entry',1,0,'2025-01-15 10:28:39','2025-01-15 10:28:40',NULL,NULL,'65ab8dfc-fa83-4f23-9bbd-53dc708e0b8f'),(65,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-01-15 10:31:22','2025-01-15 10:31:22',NULL,NULL,'99eb8336-a1eb-4183-94bf-e0843f8d8892'),(66,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-01-15 10:31:46','2025-01-15 10:31:46',NULL,NULL,'13b4297b-4b8d-4331-8649-1bf899955191'),(67,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-01-15 10:31:50','2025-01-15 10:31:50',NULL,NULL,'626fc15e-353d-4f01-992e-45294cef6319'),(68,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-01-15 10:31:55','2025-01-15 10:31:55',NULL,NULL,'974ce0d0-089d-45be-915c-65d09d1d11e9'),(69,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-01-15 10:31:59','2025-01-15 10:31:59',NULL,NULL,'3aca8dba-63d1-406c-b3ed-7c4143a9da5f'),(71,2,NULL,19,1,'craft\\elements\\Entry',1,0,'2025-01-15 10:33:06','2025-01-15 10:33:07',NULL,NULL,'5cb739e4-8b75-4a2b-a226-33c1e343b907'),(77,2,NULL,20,1,'craft\\elements\\Entry',1,0,'2025-01-15 10:36:41','2025-01-15 10:36:42',NULL,NULL,'c139b1d4-59f6-43bd-86b9-3a27d9da7ff4'),(78,51,NULL,21,3,'craft\\elements\\MatrixBlock',1,0,'2025-01-15 10:36:42','2025-01-15 10:36:42',NULL,NULL,'6f871a73-3bf5-4282-b80a-bf38a9b980bc'),(79,52,NULL,22,3,'craft\\elements\\MatrixBlock',1,0,'2025-01-15 10:36:42','2025-01-15 10:36:43',NULL,NULL,'c9fdfb10-00cd-4bbd-8b60-83ad1a63ac91'),(80,53,NULL,23,3,'craft\\elements\\MatrixBlock',1,0,'2025-01-15 10:36:42','2025-01-15 10:36:43',NULL,NULL,'8b5c2935-7cf1-4bd7-9229-de1bc4ce0a40'),(81,54,NULL,24,3,'craft\\elements\\MatrixBlock',1,0,'2025-01-15 10:36:42','2025-01-15 10:36:43',NULL,NULL,'cea6e3b9-de3f-4a2c-a860-4203e61ef7d4');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2024-12-17 21:59:01','2024-12-17 21:59:01','e04cdbb0-6de6-4762-b69c-090998dd9974'),(2,2,1,'home','__home__',1,'2024-12-17 22:43:22','2024-12-17 22:43:22','7a732212-ccb5-43cc-b4b2-de4ea24805fc'),(3,3,1,'home','__home__',1,'2024-12-17 22:43:22','2024-12-17 22:43:22','e293d4a9-fb48-412b-9104-d6f1c04b931c'),(4,4,1,'home','__home__',1,'2024-12-17 22:43:23','2024-12-17 22:43:23','a1ebed71-8fea-4834-8249-f853f25f5a72'),(5,5,1,'home','__home__',1,'2024-12-17 23:59:30','2024-12-17 23:59:30','786435a8-d0d2-427c-a210-c77ee73263eb'),(7,7,1,'home','__home__',1,'2024-12-18 00:00:42','2024-12-18 00:00:42','8becab26-26d9-4bdd-86fe-01bca5acec38'),(8,8,1,NULL,NULL,1,'2024-12-18 00:01:37','2024-12-18 00:01:37','f2b771db-3639-495c-a33c-922355d699b1'),(10,10,1,'home','__home__',1,'2024-12-18 00:01:58','2024-12-18 00:01:58','a605fac3-db9f-4935-b41f-8bcf83ef5f71'),(13,13,1,NULL,NULL,1,'2024-12-18 00:10:35','2024-12-18 00:10:35','dd2eba7d-493b-47c3-88db-98aebdcd06cc'),(14,14,1,'home','__home__',1,'2024-12-18 00:11:22','2024-12-18 00:11:22','664ccddf-f08f-4197-bfef-2fcd896d6662'),(16,16,1,NULL,NULL,1,'2024-12-18 00:12:29','2024-12-18 00:12:29','c559c690-f4dd-4930-835a-38f863d595f8'),(17,17,1,'home','__home__',1,'2024-12-18 00:12:42','2024-12-18 00:12:42','a8506579-d82d-4cf9-95e7-90c85e91c634'),(18,18,1,NULL,NULL,1,'2024-12-18 00:13:07','2024-12-18 00:13:07','eeb6b469-0ce9-441a-8ab6-ada7e5b438da'),(20,20,1,'home','__home__',1,'2024-12-18 00:13:16','2024-12-18 00:13:16','c8fd89bf-402c-48ca-a3c4-058f7715a0c0'),(22,22,1,NULL,NULL,1,'2024-12-18 00:24:27','2024-12-18 00:24:27','bdf0e1bc-8ded-4574-a38b-f3ec93a82084'),(23,23,1,'home','__home__',1,'2024-12-18 00:24:42','2024-12-18 00:24:42','f471003f-60cf-4f5f-9d65-e7e581e5a6be'),(24,24,1,'home','__home__',1,'2024-12-18 17:49:51','2024-12-18 17:49:51','3ef6c403-3854-42f7-9885-fa0087272b04'),(26,26,1,NULL,NULL,1,'2024-12-18 17:51:08','2024-12-18 17:51:08','7e97762a-c0c1-45bd-8e6b-69ce2b25d43b'),(27,27,1,NULL,NULL,1,'2024-12-18 17:51:09','2024-12-18 17:51:09','477a1ce1-44ca-47ce-b375-8d9c594075d7'),(28,28,1,NULL,NULL,1,'2024-12-18 17:51:31','2024-12-18 17:51:31','80ebdc7f-e8b5-4ab9-b903-e7c4c6d6ca66'),(29,29,1,NULL,NULL,1,'2024-12-18 17:51:39','2024-12-18 17:51:39','d966cc27-9ced-4c42-a91a-0309a14a4ef5'),(30,30,1,NULL,NULL,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','bab6e84e-f278-490b-b4d3-19184f8f55fd'),(31,31,1,NULL,NULL,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','a817c95f-6db7-4905-a29a-1d6567d47080'),(32,32,1,NULL,NULL,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','fcb253e6-2d47-40aa-b313-938e570d49af'),(33,33,1,NULL,NULL,1,'2024-12-18 17:51:51','2024-12-18 17:51:51','6f726cae-3c23-4f74-a627-12653926b553'),(34,34,1,NULL,NULL,1,'2024-12-18 17:51:57','2024-12-18 17:51:57','0aad2ac3-e5b3-4f1e-a10e-ecc0f3bdb796'),(35,35,1,NULL,NULL,1,'2024-12-18 17:51:58','2024-12-18 17:51:58','c102f98e-ab90-464d-a146-9673d776a11c'),(36,36,1,NULL,NULL,1,'2024-12-18 17:51:58','2024-12-18 17:51:58','c016d688-9ee1-4dd4-b132-225446c9df5a'),(37,37,1,NULL,NULL,1,'2024-12-18 17:51:59','2024-12-18 17:51:59','6925db1c-1b7d-4b7c-89d4-52db7bd7fea6'),(38,38,1,NULL,NULL,1,'2024-12-18 17:52:12','2024-12-18 17:52:12','01d06c27-b934-449d-af81-ea926b535037'),(39,39,1,NULL,NULL,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','8b64a3f3-e0b9-4d1b-99d6-320617d705e8'),(40,40,1,NULL,NULL,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','23db4b66-73f6-462a-96d1-fd3c3eb1ae43'),(41,41,1,NULL,NULL,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','9740eb17-67f4-4081-b6d5-7d989795b838'),(42,42,1,NULL,NULL,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','2ec4c43a-5a4b-4699-b01f-b915b6db8a01'),(43,43,1,NULL,NULL,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','1043f853-cafd-45d9-b172-33f84855cf1c'),(44,44,1,NULL,NULL,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','442a0152-c46d-4a3a-9765-f56d67c3b6e0'),(45,45,1,NULL,NULL,1,'2024-12-18 17:52:41','2024-12-18 17:52:41','a499e791-a102-41fe-9cd0-19823497a897'),(46,46,1,NULL,NULL,1,'2024-12-18 17:52:41','2024-12-18 17:52:41','1a7939b5-c6f1-4ffb-9fe8-4c601b4d2de6'),(51,51,1,NULL,NULL,1,'2024-12-18 17:53:03','2024-12-18 17:53:03','56238685-414b-4542-bd42-d198b7c37d1a'),(52,52,1,NULL,NULL,1,'2024-12-18 17:53:03','2024-12-18 17:53:03','b18f3f9f-41bc-4747-aefa-d6305ab34380'),(53,53,1,NULL,NULL,1,'2024-12-18 17:53:03','2024-12-18 17:53:03','5985e049-984c-4f59-9034-4c026ca58312'),(54,54,1,NULL,NULL,1,'2024-12-18 17:53:03','2024-12-18 17:53:03','21062559-e249-43ac-8f5c-b1e818864eea'),(55,55,1,'home','__home__',1,'2024-12-18 17:53:04','2024-12-18 17:53:04','1099718c-e816-436a-99ca-c829d5a15c0a'),(56,56,1,NULL,NULL,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','2ba9e401-d1f2-467d-a808-78618f7c24dd'),(57,57,1,NULL,NULL,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','5fad68d5-0961-4ed7-a652-3c2ba3faf643'),(58,58,1,NULL,NULL,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','b4daf6f1-12ed-4207-94ec-12c841dbfca0'),(59,59,1,NULL,NULL,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','ba44f346-a493-46cb-bad2-3a7b8e2e243c'),(60,60,1,'home','__home__',1,'2024-12-18 17:55:16','2024-12-18 17:55:16','327a0ad4-207d-41b3-9ab5-4a3a1036bb9d'),(62,62,1,'home','__home__',1,'2025-01-15 10:24:17','2025-01-15 10:24:17','4ed584b3-9343-454a-abc9-b7985dc3c9ca'),(64,64,1,'home','__home__',1,'2025-01-15 10:28:40','2025-01-15 10:28:40','bf8183be-d279-4682-afd8-2bec963f06d7'),(65,65,1,NULL,NULL,1,'2025-01-15 10:31:22','2025-01-15 10:31:22','818fd54c-b38c-44ac-97a8-1f8ce8e6743e'),(66,66,1,NULL,NULL,1,'2025-01-15 10:31:46','2025-01-15 10:31:46','d5640f13-c05c-4c2c-b9d0-2a71a7b98f3b'),(67,67,1,NULL,NULL,1,'2025-01-15 10:31:50','2025-01-15 10:31:50','1dea7535-ff69-405e-82f3-8496f65d6600'),(68,68,1,NULL,NULL,1,'2025-01-15 10:31:55','2025-01-15 10:31:55','c9f51c1e-9278-42b6-b013-05184d769bd6'),(69,69,1,NULL,NULL,1,'2025-01-15 10:31:59','2025-01-15 10:31:59','30629eaf-9a96-4d62-aadc-859373143130'),(71,71,1,'home','__home__',1,'2025-01-15 10:33:07','2025-01-15 10:33:07','0cc6d7d4-9d54-45b0-9e7c-9937695ba412'),(77,77,1,'home','__home__',1,'2025-01-15 10:36:42','2025-01-15 10:36:42','08f4c137-fcf9-47ad-bab3-66f41c8b3dd7'),(78,78,1,NULL,NULL,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','36ed4c6d-4180-4892-8649-d1ed7ab47afa'),(79,79,1,NULL,NULL,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','91a05263-9074-43a5-8bf9-21a7a0f36e0c'),(80,80,1,NULL,NULL,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','7714002d-c6be-4a8d-b18f-bd65339829d8'),(81,81,1,NULL,NULL,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','e8996cf4-6c26-4f84-a891-44627eeacbbb');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-17 22:43:22','2024-12-17 22:43:22'),(3,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-17 22:43:22','2024-12-17 22:43:22'),(4,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-17 22:43:23','2024-12-17 22:43:23'),(5,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-17 23:59:30','2024-12-17 23:59:30'),(7,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:00:42','2024-12-18 00:00:42'),(10,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:01:58','2024-12-18 00:01:58'),(14,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:11:22','2024-12-18 00:11:22'),(17,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:12:42','2024-12-18 00:12:42'),(20,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:13:16','2024-12-18 00:13:16'),(23,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 00:24:42','2024-12-18 00:24:42'),(24,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 17:49:51','2024-12-18 17:49:51'),(55,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 17:53:04','2024-12-18 17:53:04'),(60,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2024-12-18 17:55:16','2024-12-18 17:55:16'),(62,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2025-01-15 10:24:17','2025-01-15 10:24:17'),(64,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2025-01-15 10:28:40','2025-01-15 10:28:40'),(71,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2025-01-15 10:33:07','2025-01-15 10:33:07'),(77,1,NULL,1,NULL,'2024-12-17 22:43:00',NULL,NULL,'2025-01-15 10:36:42','2025-01-15 10:36:42');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Home','home',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2024-12-17 22:43:19','2024-12-17 22:43:19',NULL,'31d824d9-c0f9-4646-a9f7-74a980c65b10');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2024-12-17 21:59:00','2024-12-17 21:59:00',NULL,'46c72423-2c0a-4880-a5c7-41c47ed4a2bd'),(2,'Homepage','2024-12-17 23:50:10','2024-12-17 23:50:10',NULL,'46590a8c-c519-4611-a669-d23b84066f7d');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (10,1,8,1,0,1,'2024-12-18 17:55:14','2024-12-18 17:55:14','55a72608-4644-4271-b421-c5fa212f859a'),(11,1,8,2,0,2,'2024-12-18 17:55:14','2024-12-18 17:55:14','d508a6d8-92b8-42ed-a202-cf2a10adff38'),(12,1,9,3,0,0,'2024-12-18 17:55:14','2024-12-18 17:55:14','6fc39845-eee0-40ce-88f8-6c84fe71967e'),(13,1,9,4,0,1,'2024-12-18 17:55:14','2024-12-18 17:55:14','a9679fab-e4d8-4088-980a-2b0f9d7ee043'),(14,1,9,5,0,2,'2024-12-18 17:55:14','2024-12-18 17:55:14','523f99bb-f5d5-4576-86bc-20986b7f4e85'),(15,3,10,6,0,0,'2024-12-18 18:15:46','2024-12-18 18:15:46','ee9d0b59-7880-4a26-b192-9ea8d29d7216');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2024-12-17 22:43:19','2024-12-17 22:43:19',NULL,'5572c205-cf50-45ec-a86d-fda8d17dbc5d'),(2,'craft\\elements\\Asset','2024-12-17 23:49:22','2024-12-17 23:49:22',NULL,'cefeed96-e6a9-40f1-b237-12196e43ea3a'),(3,'craft\\elements\\MatrixBlock','2024-12-18 17:45:19','2024-12-18 17:45:19',NULL,'489a7971-5a21-4674-96df-0259ec30c792');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (2,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"431e3b0a-7509-4ece-b4e2-1c6cd75f3b09\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-12-17 23:49:23','2024-12-17 23:49:23','3ff7d041-85a4-40ab-a343-cab1600293d2'),(8,1,'Hero','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"912d5ff8-1bdd-4d9d-9f0f-73d87cbeaffb\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"46968876-4e79-4e7d-aeee-29c3a38262f9\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a79e18ee-bb78-4568-be9c-24ed22fc3be1\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8009fea4-24bf-420c-8893-a6635528c300\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2bd45805-6b4f-44e5-abbe-e7b9d9486620\"}]',1,'2024-12-18 17:55:14','2024-12-18 17:55:14','b22795ce-d43e-462e-b46b-7465194dd5ba'),(9,1,'Slider','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"7859fac1-757e-412a-ba5e-3499a8a6d701\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f964a032-555a-401e-99df-fbbe1aff6d16\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"20e63bf3-15b5-45c3-8d39-b48692430dbb\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"80118ba7-6f10-4eec-b489-5f775d7f82bb\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ee19bf47-dad4-4796-8997-4b856aadf812\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"560bd468-1d66-4847-bfb7-7f59d24e7aaa\"}]',2,'2024-12-18 17:55:14','2024-12-18 17:55:14','08355518-dc37-47f4-813b-d52ce507eed7'),(10,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8d80dad4-9e3b-4bab-866f-34a2ef72e00d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e84cec90-0a9b-43bc-8bef-e51676b4e036\"}]',1,'2024-12-18 18:15:46','2024-12-18 18:15:46','8318e75c-6ba4-4090-b818-6e64a5eb13bb');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,2,'Hero Title','heroTitle','global','fixrbccy',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-12-17 23:50:48','2024-12-17 23:50:48','a79e18ee-bb78-4568-be9c-24ed22fc3be1'),(2,2,'Hero Background Image','heroBackgroundImage','global',NULL,'Add a background image',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Upload a background image\",\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-12-17 23:54:00','2024-12-17 23:54:00','2bd45805-6b4f-44e5-abbe-e7b9d9486620'),(3,2,'Slider Title','sliderTitle','global','bwxxppql','Title for the slider',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-12-18 17:37:34','2024-12-18 17:37:34','f964a032-555a-401e-99df-fbbe1aff6d16'),(4,2,'Slider Description','sliderDescription','global','qgvuhscd','Description for slider',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-12-18 17:38:58','2024-12-18 17:38:58','80118ba7-6f10-4eec-b489-5f775d7f82bb'),(5,2,'Slider Images','sliderImages','global',NULL,'Add images for the slider',0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":2,\"maxBlocks\":null,\"contentTable\":\"{{%matrixcontent_sliderimages}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2024-12-18 17:45:18','2024-12-18 17:46:57','560bd468-1d66-4847-bfb7-7f59d24e7aaa'),(6,NULL,'Slide Image','slideImage','matrixBlockType:728ff468-308d-462a-937e-76ff0ee6f75b',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-12-18 17:45:19','2024-12-18 18:15:46','e84cec90-0a9b-43bc-8bef-e51676b4e036');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-12-17 22:00:11','2024-12-17 22:00:11','39e1dd42-9eef-4108-943a-51fff33e2466');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.13.7','4.5.3.0',0,'dhdofutosvec','3@zdxncsnwdi','2024-12-17 21:59:00','2025-01-15 10:27:11','10444e04-3900-4b46-9ef0-789688ef9415');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (51,2,5,1,NULL,'2024-12-18 17:53:03','2024-12-18 17:53:03'),(52,2,5,1,NULL,'2024-12-18 17:53:03','2024-12-18 17:53:03'),(53,2,5,1,NULL,'2024-12-18 17:53:03','2024-12-18 17:53:03'),(54,2,5,1,NULL,'2024-12-18 17:53:03','2024-12-18 17:53:03'),(56,55,5,1,NULL,'2024-12-18 17:53:04','2024-12-18 17:53:04'),(57,55,5,1,NULL,'2024-12-18 17:53:04','2024-12-18 17:53:04'),(58,55,5,1,NULL,'2024-12-18 17:53:05','2024-12-18 17:53:05'),(59,55,5,1,NULL,'2024-12-18 17:53:05','2024-12-18 17:53:05'),(78,77,5,1,NULL,'2025-01-15 10:36:42','2025-01-15 10:36:42'),(79,77,5,1,NULL,'2025-01-15 10:36:43','2025-01-15 10:36:43'),(80,77,5,1,NULL,'2025-01-15 10:36:43','2025-01-15 10:36:43'),(81,77,5,1,NULL,'2025-01-15 10:36:43','2025-01-15 10:36:43');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (51,2,1),(52,2,2),(53,2,3),(54,2,4),(56,55,1),(56,60,1),(56,62,1),(56,64,1),(56,71,1),(57,55,2),(57,60,2),(57,62,2),(57,64,2),(57,71,2),(58,55,3),(58,60,3),(58,62,3),(58,64,3),(58,71,3),(59,55,4),(59,60,4),(59,62,4),(59,64,4),(59,71,4),(78,77,1),(79,77,2),(80,77,3),(81,77,4);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,5,3,'Slide','slide',1,'2024-12-18 17:45:19','2024-12-18 17:45:19','728ff468-308d-462a-937e-76ff0ee6f75b');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_sliderimages`
--

LOCK TABLES `matrixcontent_sliderimages` WRITE;
/*!40000 ALTER TABLE `matrixcontent_sliderimages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_sliderimages` VALUES (1,26,1,'2024-12-18 17:51:08','2024-12-18 17:51:08','626b9c9b-0ba6-4521-a217-e95643fd2775'),(2,27,1,'2024-12-18 17:51:09','2024-12-18 17:51:09','6f23a977-424d-4f6c-a20e-b9734d97a516'),(3,30,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','315c01c3-3cf9-4ff5-be19-781b40b45d50'),(4,31,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','646541b9-5bfc-4425-be7f-faf878ff5465'),(5,32,1,'2024-12-18 17:51:46','2024-12-18 17:51:46','ec9d6ac7-dac7-4443-9038-a37fac73a2d2'),(6,34,1,'2024-12-18 17:51:57','2024-12-18 17:51:57','5cfe7b72-63d0-4215-af25-455d154c0db2'),(7,35,1,'2024-12-18 17:51:58','2024-12-18 17:51:58','a39f232d-45c4-4d00-a32f-11e23fcde647'),(8,36,1,'2024-12-18 17:51:58','2024-12-18 17:51:58','d3fd212c-648f-4e91-8000-7d31fcb1aa9b'),(9,37,1,'2024-12-18 17:51:59','2024-12-18 17:51:59','68dd51fa-5172-44ee-9aea-978439f3a289'),(10,39,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','587949b9-a328-4726-ace6-48edf32e6120'),(11,40,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','0331a988-fc05-4d81-b7be-4621cfec27ae'),(12,41,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','365ab0ae-014c-43df-8d9b-552e768fa98a'),(13,42,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','2f499495-e9fb-4608-8963-72833b043fff'),(14,43,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','2ed05f2a-da25-4681-925d-61a1df3f6627'),(15,44,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','6c9a8350-26d2-413c-b3d1-da6b82d25fcd'),(16,45,1,'2024-12-18 17:52:41','2024-12-18 17:52:41','e78b1ec9-1ecd-4fe7-b727-9264b4324534'),(17,46,1,'2024-12-18 17:52:41','2024-12-18 17:52:41','ab76506c-c7b1-4da1-9403-9718490cc412'),(22,51,1,'2024-12-18 17:53:03','2025-01-15 10:36:42','3ff6fcfc-93c2-4a23-9446-eb9f5a7ef878'),(23,52,1,'2024-12-18 17:53:03','2025-01-15 10:36:42','64fa0153-c20b-4cc6-9ced-0e849d7727bb'),(24,53,1,'2024-12-18 17:53:03','2025-01-15 10:36:42','f98c0be0-6c13-48a1-b4b2-64efd6dee8ad'),(25,54,1,'2024-12-18 17:53:03','2025-01-15 10:36:42','6f7df201-6c8b-46a1-915d-30ea8876bcc3'),(26,56,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','2ec661e6-cb70-4d51-932e-42909c0f11bd'),(27,57,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','7ed64f56-82e7-49ce-83ff-ec3a81d9f408'),(28,58,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','f967e332-e9ef-4ec5-a238-8b4db26432d0'),(29,59,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','89c92b8c-e154-42df-8c7e-a3030af0533b'),(34,78,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','89d1cf26-e808-49b6-9b24-223c4626d089'),(35,79,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','5b3fa398-9d61-4172-bc8c-6a2796adaad4'),(36,80,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','b1f0ee2c-3510-48e5-a5fc-4c4c7170cf08'),(37,81,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','cf6c39a4-af7c-4243-bfaa-82bf62da7279');
/*!40000 ALTER TABLE `matrixcontent_sliderimages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','444b07bc-9ce0-4278-8950-b977210e1e36'),(2,'craft','m210121_145800_asset_indexing_changes','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','fe354c1d-1c23-444c-bb41-d91a63f602a1'),(3,'craft','m210624_222934_drop_deprecated_tables','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','385ff738-baab-4456-8bb3-899fe3ef9f02'),(4,'craft','m210724_180756_rename_source_cols','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','437c9e52-9fef-49fd-bd23-0361413352f8'),(5,'craft','m210809_124211_remove_superfluous_uids','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','7ff7d1e2-f0c1-4267-ad72-2472b0138005'),(6,'craft','m210817_014201_universal_users','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','2758a192-2ac5-4acf-a712-b4beb6bbe8a2'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','54a0c191-e765-4d0c-9e14-97aa7074651f'),(8,'craft','m211115_135500_image_transformers','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','57ac03a1-2ab8-419a-bbea-2a3f55ec6c71'),(9,'craft','m211201_131000_filesystems','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','2f29b898-9506-4244-b77e-5d223ec54005'),(10,'craft','m220103_043103_tab_conditions','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','41f5bece-4f56-48a1-89e6-fe01b4cdc923'),(11,'craft','m220104_003433_asset_alt_text','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','c42bb920-a684-43af-8be8-4fa8e19fc0ed'),(12,'craft','m220123_213619_update_permissions','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','61fc4ed2-79e3-4583-8730-8746122ca5a2'),(13,'craft','m220126_003432_addresses','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','57792fc4-acea-4de9-b1e3-da9fd19f8ed3'),(14,'craft','m220209_095604_add_indexes','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','1d48b9f8-d5bf-4fde-a0a9-f3cae14c931d'),(15,'craft','m220213_015220_matrixblocks_owners_table','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','85652341-d4b5-47a0-aab7-e577fd7080c5'),(16,'craft','m220214_000000_truncate_sessions','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','d10b8a6f-277b-4213-9dbb-478d404f1bb2'),(17,'craft','m220222_122159_full_names','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','bf058996-ece1-4e07-b1d7-586494c0f29e'),(18,'craft','m220223_180559_nullable_address_owner','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','7499f1f4-2b91-4b72-a5a7-130a200164c8'),(19,'craft','m220225_165000_transform_filesystems','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','1224846a-1e85-4335-9f54-5d76f363429b'),(20,'craft','m220309_152006_rename_field_layout_elements','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','5746f1f7-a2fd-4bae-a2a0-4ab60dd34fed'),(21,'craft','m220314_211928_field_layout_element_uids','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','cb193040-f2c5-4eca-ac14-ddb0c115d4e1'),(22,'craft','m220316_123800_transform_fs_subpath','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','ca6a85b9-7ee6-460e-b639-7dc34b5f6a1c'),(23,'craft','m220317_174250_release_all_jobs','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','6c28791e-b4d9-4e67-aa54-8f9152ac9f34'),(24,'craft','m220330_150000_add_site_gql_schema_components','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','55bd9592-3af6-4d31-b989-4e4d831996d5'),(25,'craft','m220413_024536_site_enabled_string','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','057c7701-95c9-470a-9f22-e471af5da6c3'),(26,'craft','m221027_160703_add_image_transform_fill','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','f707efd9-dc66-46e0-bc81-c2c037c3ae77'),(27,'craft','m221028_130548_add_canonical_id_index','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','65ac7b64-6828-4ab9-9975-d9d47a4b7b2c'),(28,'craft','m221118_003031_drop_element_fks','2024-12-17 21:59:02','2024-12-17 21:59:02','2024-12-17 21:59:02','2d3eefb0-651d-4f7d-8f9d-dfecbe1fd32b'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','0087d3e1-ce4c-4f4f-95bb-caa374fcdf52'),(30,'craft','m230226_013114_drop_plugin_license_columns','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','9f0d35d7-3ab1-452c-9f13-ae8e91c15cee'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','2567c427-3353-4dfd-9f9c-d3fb9e68dfe4'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','137d650c-31ae-4c45-a6e0-eb105a8b6ab5'),(33,'craft','m230710_162700_element_activity','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','c2ca62fe-1121-43ac-a688-89524d34eea9'),(34,'craft','m230820_162023_fix_cache_id_type','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','7f2bc2b7-60bd-41d0-866b-d3e682a309e5'),(35,'craft','m230826_094050_fix_session_id_type','2024-12-17 21:59:03','2024-12-17 21:59:03','2024-12-17 21:59:03','fc872914-9169-42d5-9bb7-b035291ac7ca');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1736936829'),('email.fromEmail','\"sheldonsaviodsouza@gmail.com\"'),('email.fromName','\"Imagic Ddev\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.autocomplete','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.autocorrect','true'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.class','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.disabled','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.id','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.inputType','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.max','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.min','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.name','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.orientation','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.placeholder','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.readonly','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.requirable','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.size','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.step','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.title','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.uid','\"912d5ff8-1bdd-4d9d-9f0f-73d87cbeaffb\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.0.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.fieldUid','\"a79e18ee-bb78-4568-be9c-24ed22fc3be1\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.required','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.uid','\"46968876-4e79-4e7d-aeee-29c3a38262f9\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.1.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.fieldUid','\"2bd45805-6b4f-44e5-abbe-e7b9d9486620\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.required','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.uid','\"8009fea4-24bf-420c-8893-a6635528c300\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.elements.2.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.name','\"Hero\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.uid','\"b22795ce-d43e-462e-b46b-7465194dd5ba\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.0.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.fieldUid','\"f964a032-555a-401e-99df-fbbe1aff6d16\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.required','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.uid','\"7859fac1-757e-412a-ba5e-3499a8a6d701\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.0.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.fieldUid','\"80118ba7-6f10-4eec-b489-5f775d7f82bb\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.required','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.uid','\"20e63bf3-15b5-45c3-8d39-b48692430dbb\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.1.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.elementCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.fieldUid','\"560bd468-1d66-4847-bfb7-7f59d24e7aaa\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.instructions','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.label','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.required','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.tip','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.uid','\"ee19bf47-dad4-4796-8997-4b856aadf812\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.warning','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.elements.2.width','100'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.name','\"Slider\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.uid','\"08355518-dc37-47f4-813b-d52ce507eed7\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.fieldLayouts.5572c205-cf50-45ec-a86d-fda8d17dbc5d.tabs.1.userCondition','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.handle','\"home\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.hasTitleField','false'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.name','\"Home\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.section','\"fec291cf-9bbc-46ad-b520-97b67bbcc7e9\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.showStatusField','true'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.slugTranslationKeyFormat','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.slugTranslationMethod','\"site\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.sortOrder','1'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.titleFormat','\"{section.name|raw}\"'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.titleTranslationKeyFormat','null'),('entryTypes.31d824d9-c0f9-4646-a9f7-74a980c65b10.titleTranslationMethod','\"site\"'),('fieldGroups.46590a8c-c519-4611-a669-d23b84066f7d.name','\"Homepage\"'),('fieldGroups.46c72423-2c0a-4880-a5c7-41c47ed4a2bd.name','\"Common\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.columnSuffix','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.contentColumnType','\"string\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.fieldGroup','\"46590a8c-c519-4611-a669-d23b84066f7d\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.handle','\"heroBackgroundImage\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.instructions','\"Add a background image\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.name','\"Hero Background Image\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.searchable','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.allowedKinds.0','\"image\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.allowSelfRelations','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.allowSubfolders','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.allowUploads','true'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.branchLimit','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.defaultUploadLocationSource','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.defaultUploadLocationSubpath','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.localizeRelations','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.maintainHierarchy','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.maxRelations','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.minRelations','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.previewMode','\"full\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.restrictedDefaultUploadSubpath','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.restrictedLocationSource','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.restrictedLocationSubpath','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.restrictFiles','true'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.restrictLocation','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.selectionLabel','\"Upload a background image\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.showSiteMenu','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.showUnpermittedFiles','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.showUnpermittedVolumes','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.sources.0','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.targetSiteId','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.validateRelatedElements','false'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.settings.viewMode','\"list\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.translationKeyFormat','null'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.translationMethod','\"site\"'),('fields.2bd45805-6b4f-44e5-abbe-e7b9d9486620.type','\"craft\\\\fields\\\\Assets\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.columnSuffix','null'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.contentColumnType','\"string\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.fieldGroup','\"46590a8c-c519-4611-a669-d23b84066f7d\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.handle','\"sliderImages\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.instructions','\"Add images for the slider\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.name','\"Slider Images\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.searchable','false'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.settings.contentTable','\"{{%matrixcontent_sliderimages}}\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.settings.maxBlocks','null'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.settings.minBlocks','2'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.settings.propagationKeyFormat','null'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.settings.propagationMethod','\"all\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.translationKeyFormat','null'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.translationMethod','\"site\"'),('fields.560bd468-1d66-4847-bfb7-7f59d24e7aaa.type','\"craft\\\\fields\\\\Matrix\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.columnSuffix','\"qgvuhscd\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.contentColumnType','\"text\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.fieldGroup','\"46590a8c-c519-4611-a669-d23b84066f7d\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.handle','\"sliderDescription\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.instructions','\"Description for slider\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.name','\"Slider Description\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.searchable','false'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.byteLimit','null'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.charLimit','null'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.code','false'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.columnType','null'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.initialRows','4'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.multiline','false'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.placeholder','null'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.settings.uiMode','\"normal\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.translationKeyFormat','null'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.translationMethod','\"none\"'),('fields.80118ba7-6f10-4eec-b489-5f775d7f82bb.type','\"craft\\\\fields\\\\PlainText\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.columnSuffix','\"fixrbccy\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.contentColumnType','\"text\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.fieldGroup','\"46590a8c-c519-4611-a669-d23b84066f7d\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.handle','\"heroTitle\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.instructions','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.name','\"Hero Title\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.searchable','false'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.byteLimit','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.charLimit','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.code','false'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.columnType','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.initialRows','4'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.multiline','false'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.placeholder','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.settings.uiMode','\"normal\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.translationKeyFormat','null'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.translationMethod','\"none\"'),('fields.a79e18ee-bb78-4568-be9c-24ed22fc3be1.type','\"craft\\\\fields\\\\PlainText\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.columnSuffix','\"bwxxppql\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.contentColumnType','\"text\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.fieldGroup','\"46590a8c-c519-4611-a669-d23b84066f7d\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.handle','\"sliderTitle\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.instructions','\"Title for the slider\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.name','\"Slider Title\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.searchable','false'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.byteLimit','null'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.charLimit','null'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.code','false'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.columnType','null'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.initialRows','4'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.multiline','false'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.placeholder','null'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.settings.uiMode','\"normal\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.translationKeyFormat','null'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.translationMethod','\"none\"'),('fields.f964a032-555a-401e-99df-fbbe1aff6d16.type','\"craft\\\\fields\\\\PlainText\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/assets\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"/assets\"'),('graphql.schemas.39e1dd42-9eef-4108-943a-51fff33e2466.isPublic','true'),('graphql.schemas.39e1dd42-9eef-4108-943a-51fff33e2466.name','\"Public Schema\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.field','\"560bd468-1d66-4847-bfb7-7f59d24e7aaa\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elementCondition','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.fieldUid','\"e84cec90-0a9b-43bc-8bef-e51676b4e036\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.label','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.required','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.tip','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.uid','\"8d80dad4-9e3b-4bab-866f-34a2ef72e00d\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.warning','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.elements.0.width','100'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.name','\"Content\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.uid','\"8318e75c-6ba4-4090-b818-6e64a5eb13bb\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fieldLayouts.489a7971-5a21-4674-96df-0259ec30c792.tabs.0.userCondition','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.columnSuffix','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.contentColumnType','\"string\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.fieldGroup','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.handle','\"slideImage\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.instructions','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.name','\"Slide Image\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.searchable','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.allowedKinds.0','\"image\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.allowSelfRelations','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.allowSubfolders','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.allowUploads','true'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.branchLimit','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.defaultUploadLocationSource','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.localizeRelations','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.maintainHierarchy','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.maxRelations','1'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.minRelations','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.previewMode','\"full\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.restrictedLocationSource','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.restrictFiles','true'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.restrictLocation','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.selectionLabel','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.showSiteMenu','true'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.showUnpermittedFiles','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.sources.0','\"volume:900eeaf1-e8d6-4bbb-b041-5d9b349c082c\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.targetSiteId','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.validateRelatedElements','false'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.settings.viewMode','\"list\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.translationKeyFormat','null'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.translationMethod','\"site\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.fields.e84cec90-0a9b-43bc-8bef-e51676b4e036.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.handle','\"slide\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.name','\"Slide\"'),('matrixBlockTypes.728ff468-308d-462a-937e-76ff0ee6f75b.sortOrder','1'),('meta.__names__.10cd244d-1065-43ca-aee5-e227035c5887','\"Imagic Ddev\"'),('meta.__names__.2bd45805-6b4f-44e5-abbe-e7b9d9486620','\"Hero Background Image\"'),('meta.__names__.31d824d9-c0f9-4646-a9f7-74a980c65b10','\"Home\"'),('meta.__names__.39e1dd42-9eef-4108-943a-51fff33e2466','\"Public Schema\"'),('meta.__names__.46590a8c-c519-4611-a669-d23b84066f7d','\"Homepage\"'),('meta.__names__.46c72423-2c0a-4880-a5c7-41c47ed4a2bd','\"Common\"'),('meta.__names__.560bd468-1d66-4847-bfb7-7f59d24e7aaa','\"Slider Images\"'),('meta.__names__.728ff468-308d-462a-937e-76ff0ee6f75b','\"Slide\"'),('meta.__names__.80118ba7-6f10-4eec-b489-5f775d7f82bb','\"Slider Description\"'),('meta.__names__.85be3886-0974-4da8-9546-cd3b8dad0110','\"Imagic Ddev\"'),('meta.__names__.900eeaf1-e8d6-4bbb-b041-5d9b349c082c','\"Uploads\"'),('meta.__names__.a79e18ee-bb78-4568-be9c-24ed22fc3be1','\"Hero Title\"'),('meta.__names__.e84cec90-0a9b-43bc-8bef-e51676b4e036','\"Slide Image\"'),('meta.__names__.f964a032-555a-401e-99df-fbbe1aff6d16','\"Slider Title\"'),('meta.__names__.fec291cf-9bbc-46ad-b520-97b67bbcc7e9','\"Home\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.defaultPlacement','\"end\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.enableVersioning','true'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.handle','\"home\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.name','\"Home\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.propagationMethod','\"all\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.siteSettings.10cd244d-1065-43ca-aee5-e227035c5887.enabledByDefault','true'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.siteSettings.10cd244d-1065-43ca-aee5-e227035c5887.hasUrls','true'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.siteSettings.10cd244d-1065-43ca-aee5-e227035c5887.template','\"home.twig\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.siteSettings.10cd244d-1065-43ca-aee5-e227035c5887.uriFormat','\"__home__\"'),('sections.fec291cf-9bbc-46ad-b520-97b67bbcc7e9.type','\"single\"'),('siteGroups.85be3886-0974-4da8-9546-cd3b8dad0110.name','\"Imagic Ddev\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.handle','\"default\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.hasUrls','true'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.language','\"en-NZ\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.name','\"Imagic Ddev\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.primary','true'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.siteGroup','\"85be3886-0974-4da8-9546-cd3b8dad0110\"'),('sites.10cd244d-1065-43ca-aee5-e227035c5887.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Imagic Ddev\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elementCondition','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.autocapitalize','true'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.autocomplete','false'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.autocorrect','true'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.class','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.disabled','false'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.elementCondition','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.id','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.inputType','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.instructions','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.label','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.max','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.min','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.name','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.orientation','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.placeholder','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.readonly','false'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.requirable','false'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.size','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.step','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.tip','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.title','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.uid','\"431e3b0a-7509-4ece-b4e2-1c6cd75f3b09\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.userCondition','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.warning','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.elements.0.width','100'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.name','\"Content\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.uid','\"3ff7d041-85a4-40ab-a343-cab1600293d2\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fieldLayouts.cefeed96-e6a9-40f1-b237-12196e43ea3a.tabs.0.userCondition','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.fs','\"uploads\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.handle','\"uploads\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.name','\"Uploads\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.sortOrder','1'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.titleTranslationKeyFormat','null'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.titleTranslationMethod','\"site\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.transformFs','\"\"'),('volumes.900eeaf1-e8d6-4bbb-b041-5d9b349c082c.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (3,2,10,NULL,8,1,'2024-12-18 00:01:58','2024-12-18 00:01:58','39b475bb-f6d0-436b-836d-796e8268c8d7'),(7,2,14,NULL,13,1,'2024-12-18 00:11:22','2024-12-18 00:11:22','b4f3da94-c3e9-48a5-b67e-27a1da541431'),(12,2,20,NULL,18,1,'2024-12-18 00:13:16','2024-12-18 00:13:16','f0d35830-c749-497b-98a9-df8ea89878a9'),(15,6,34,NULL,28,1,'2024-12-18 17:51:57','2024-12-18 17:51:57','5979c8b5-9675-4367-b8cb-78d23b150d58'),(16,6,39,NULL,28,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','1ac2659d-318d-4dac-b72e-a82322bf91b5'),(17,6,40,NULL,29,1,'2024-12-18 17:52:22','2024-12-18 17:52:22','583f2bc3-1694-4d7e-8dc1-1d11be27f817'),(18,6,43,NULL,28,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','793f783e-510f-45e2-80ba-72d18c021ea8'),(19,6,44,NULL,29,1,'2024-12-18 17:52:40','2024-12-18 17:52:40','ce08576e-384d-47ea-ada2-8567159d82ef'),(20,6,45,NULL,33,1,'2024-12-18 17:52:41','2024-12-18 17:52:41','4578877c-94c4-444b-a497-484b00038989'),(29,6,56,NULL,28,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','a13810b6-679c-409c-8356-9f4cff406b51'),(30,6,57,NULL,29,1,'2024-12-18 17:53:04','2024-12-18 17:53:04','36bd929f-1860-420b-b3a5-26b00743f347'),(31,6,58,NULL,33,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','71037c87-ce6c-4f6a-bc31-b7cf37fc4d86'),(32,6,59,NULL,38,1,'2024-12-18 17:53:05','2024-12-18 17:53:05','e81439ff-5235-4c0d-a3bf-e44c105bc2ee'),(35,2,62,NULL,8,1,'2025-01-15 10:24:17','2025-01-15 10:24:17','6a1a3752-025d-4280-9a67-0e3960196bd1'),(38,2,64,NULL,8,1,'2025-01-15 10:28:40','2025-01-15 10:28:40','65fcfdad-5896-4c25-a781-b42ce11b67bb'),(40,2,2,NULL,65,1,'2025-01-15 10:33:06','2025-01-15 10:33:06','dbc0536a-4e14-4938-822b-d838657e7b7b'),(41,2,71,NULL,65,1,'2025-01-15 10:33:07','2025-01-15 10:33:07','a0641cf5-bb23-4c5b-9db7-f1bfcb7053ee'),(47,6,51,NULL,69,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','109bdd7b-a00c-49b7-af55-12e3811d5887'),(48,6,52,NULL,68,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','c8d52c18-a790-4adc-ae6f-f6eb87cc6d08'),(49,6,53,NULL,67,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','34edfa6b-e3c8-4ba2-a12c-210eb02501ee'),(50,6,54,NULL,66,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','741addaa-87e4-4272-8936-2b10dd4cdd4e'),(51,2,77,NULL,65,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','dfd487f9-5ef5-4fcf-964a-7b2b71ec013c'),(52,6,78,NULL,69,1,'2025-01-15 10:36:42','2025-01-15 10:36:42','22cd02e2-a921-4825-9214-1743a4960688'),(53,6,79,NULL,68,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','1fe261af-5d42-4a56-9e7a-2e69a1878017'),(54,6,80,NULL,67,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','063de955-fcad-4022-b922-87a99b0a45f4'),(55,6,81,NULL,66,1,'2025-01-15 10:36:43','2025-01-15 10:36:43','a51bb400-13a5-478d-8cf0-c631d0ee2743');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,2,1,3,NULL),(4,2,1,4,''),(5,2,1,5,'Applied “Draft 1”'),(6,2,1,6,'Applied “Draft 1”'),(7,2,1,7,'Applied “Draft 1”'),(8,2,1,8,''),(9,2,1,9,'Applied “Draft 1”'),(10,2,1,10,NULL),(11,2,1,11,'Applied “Draft 1”'),(12,51,1,1,NULL),(13,52,1,1,NULL),(14,53,1,1,NULL),(15,54,1,1,NULL),(16,2,1,12,NULL),(17,2,1,13,'Applied “Draft 1”'),(18,2,1,14,'Applied “Draft 1”'),(19,2,1,15,'Applied “Draft 1”'),(20,2,1,16,'Applied “Draft 1”'),(21,51,1,2,NULL),(22,52,1,2,NULL),(23,53,1,2,NULL),(24,54,1,2,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' sheldonsaviodsouza gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' sheldon '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(8,'alt',0,1,''),(8,'extension',0,1,' jpg '),(8,'filename',0,1,' hero jpg '),(8,'kind',0,1,' image '),(8,'slug',0,1,''),(8,'title',0,1,' hero '),(13,'alt',0,1,''),(13,'extension',0,1,' jpg '),(13,'filename',0,1,' hero 2024 12 18 001035 paba jpg '),(13,'kind',0,1,' image '),(13,'slug',0,1,''),(13,'title',0,1,' hero '),(16,'alt',0,1,''),(16,'extension',0,1,' jpg '),(16,'filename',0,1,' hero 2024 12 18 001229 maxf jpg '),(16,'kind',0,1,' image '),(16,'slug',0,1,''),(16,'title',0,1,' hero '),(18,'alt',0,1,''),(18,'extension',0,1,' jpg '),(18,'filename',0,1,' hero 2024 12 18 001307 jwwm jpg '),(18,'kind',0,1,' image '),(18,'slug',0,1,''),(18,'title',0,1,' hero '),(22,'alt',0,1,''),(22,'extension',0,1,' jpg '),(22,'filename',0,1,' hero 2024 12 18 002426 hyqb jpg '),(22,'kind',0,1,' image '),(22,'slug',0,1,''),(22,'title',0,1,' hero '),(26,'slug',0,1,''),(27,'slug',0,1,''),(28,'alt',0,1,''),(28,'extension',0,1,' jpg '),(28,'filename',0,1,' cbhb jpg '),(28,'kind',0,1,' image '),(28,'slug',0,1,''),(28,'title',0,1,' cbhb '),(29,'alt',0,1,''),(29,'extension',0,1,' jpg '),(29,'filename',0,1,' faringdon jpg '),(29,'kind',0,1,' image '),(29,'slug',0,1,''),(29,'title',0,1,' faringdon '),(30,'slug',0,1,''),(31,'slug',0,1,''),(32,'slug',0,1,''),(33,'alt',0,1,''),(33,'extension',0,1,' jpg '),(33,'filename',0,1,' platinum jpg '),(33,'kind',0,1,' image '),(33,'slug',0,1,''),(33,'title',0,1,' platinum '),(34,'slug',0,1,''),(35,'slug',0,1,''),(36,'slug',0,1,''),(37,'slug',0,1,''),(38,'alt',0,1,''),(38,'extension',0,1,' jpg '),(38,'filename',0,1,' signtech jpg '),(38,'kind',0,1,' image '),(38,'slug',0,1,''),(38,'title',0,1,' signtech '),(39,'slug',0,1,''),(40,'slug',0,1,''),(41,'slug',0,1,''),(42,'slug',0,1,''),(43,'slug',0,1,''),(44,'slug',0,1,''),(45,'slug',0,1,''),(46,'slug',0,1,''),(51,'slug',0,1,''),(52,'slug',0,1,''),(53,'slug',0,1,''),(54,'slug',0,1,''),(65,'alt',0,1,''),(65,'extension',0,1,' jpg '),(65,'filename',0,1,' hero jpg '),(65,'kind',0,1,' image '),(65,'slug',0,1,''),(65,'title',0,1,' hero '),(66,'alt',0,1,''),(66,'extension',0,1,' jpg '),(66,'filename',0,1,' cbhb jpg '),(66,'kind',0,1,' image '),(66,'slug',0,1,''),(66,'title',0,1,' cbhb '),(67,'alt',0,1,''),(67,'extension',0,1,' jpg '),(67,'filename',0,1,' faringdon jpg '),(67,'kind',0,1,' image '),(67,'slug',0,1,''),(67,'title',0,1,' faringdon '),(68,'alt',0,1,''),(68,'extension',0,1,' jpg '),(68,'filename',0,1,' platinum jpg '),(68,'kind',0,1,' image '),(68,'slug',0,1,''),(68,'title',0,1,' platinum '),(69,'alt',0,1,''),(69,'extension',0,1,' jpg '),(69,'filename',0,1,' signtech jpg '),(69,'kind',0,1,' image '),(69,'slug',0,1,''),(69,'title',0,1,' signtech ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all','end',NULL,'2024-12-17 22:43:18','2024-12-17 22:43:18',NULL,'fec291cf-9bbc-46ad-b520-97b67bbcc7e9');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','home.twig',1,'2024-12-17 22:43:18','2024-12-17 22:43:18','539ee4aa-13e7-442a-8ec3-d454115ef215');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Imagic Ddev','2024-12-17 21:59:00','2024-12-17 21:59:00',NULL,'85be3886-0974-4da8-9546-cd3b8dad0110');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','Imagic Ddev','default','en-NZ',1,'$PRIMARY_SITE_URL',1,'2024-12-17 21:59:00','2024-12-17 21:59:00',NULL,'10cd244d-1065-43ca-aee5-e227035c5887');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-NZ\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'sheldon',NULL,NULL,NULL,'sheldonsaviodsouza@gmail.com','$2y$13$2LOKpt66SE0olYEw8vw8s..URw/QUA0OjGfo7Mw9oc28ESr4/TjPa','2025-01-15 18:30:19',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-12-17 21:59:02','2024-12-17 21:59:02','2025-01-15 18:30:19');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Uploads','','2024-12-17 23:49:23','2024-12-17 23:49:23','8fdb5168-b368-46a2-9053-d2deacc68c02'),(2,NULL,NULL,'Temporary filesystem',NULL,'2024-12-18 00:01:05','2024-12-18 00:01:05','0d473a33-3e95-4f66-9132-23ba0158e339'),(3,2,NULL,'user_1','user_1/','2024-12-18 00:01:05','2024-12-18 00:01:05','5da7282b-dcfe-4d92-9334-729c7649bb9d');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,2,'Uploads','uploads','uploads','','','site',NULL,1,'2024-12-17 23:49:23','2024-12-17 23:49:23',NULL,'900eeaf1-e8d6-4bbb-b041-5d9b349c082c');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-12-17 21:59:10','2024-12-17 21:59:10','9a64d0fb-bebb-408b-98c6-7e28ca586496'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-12-17 21:59:10','2024-12-17 21:59:10','14c4348a-e9d0-431a-9ff8-a57b3078cadb'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-12-17 21:59:10','2024-12-17 21:59:10','ec83afbe-68f4-452e-a476-bae9e88e5099'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-12-17 21:59:10','2024-12-17 21:59:10','545c4104-c395-43ce-b459-bfb51328d134');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-16  9:25:51
